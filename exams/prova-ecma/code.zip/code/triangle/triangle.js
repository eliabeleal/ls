module.exports = class Triangle {

}
